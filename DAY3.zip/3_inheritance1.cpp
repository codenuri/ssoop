#include <iostream>
#include <string>

// 133 page ~

class Student 
{	
	std::string name;
	int    id;
};

class Professor
{
	std::string name;
	int    major;
};

int main()
{
	Student s;
	Professor p;
}
