#include <iostream>

class Animal
{
public:
	int age;
};
class Dog : public Animal
{
public:
	int color;
};

int main()
{
	Animal a;
	Dog    d;

	Animal* p = &d;

	Dog* pd = static_cast<Dog*>(p);
	pd->color = 10;
}


