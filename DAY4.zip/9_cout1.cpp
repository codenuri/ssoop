#include <iostream>

// cout �� ���� ( 169 ~ )
int main()
{
	int    n = 10;
	double d = 3.4;

	std::cout << n;
	std::cout << d;
	
}


