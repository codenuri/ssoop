
#include <iostream>

class Point
{
public:
	int x, y;

	Point(int a, int b) { }
	~Point() { std::cout << "~Point()" << std::endl; }
};

void draw_line(const Point& from, const Point& to) {}

int main()
{
	// (1,1) ~ (5,5) �� ���� �׸��� �ͽ��ϴ�.
	Point p1{ 1,1 };
	Point p2{ 5,5 };

	draw_line(p1, p2); // ??


	std::cout << "-----" << std::endl;
}





