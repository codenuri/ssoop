#include <iostream>
#include <vector>
#include <list>
#include <deque>

int main()
{
	std::vector<int> v = { 1,2,3,4,5 };
	std::list<int>   s = { 1,2,3,4,5 };

	// #1. 제거와 반환을 동시에 하는 멤버 함수는 없습니다.
	// => 안전한 컨테이너를 만들기 위해서 선택한 방법.

	int n = v.back();
	v.pop_back();	

	std::cout << n << std::endl;



	// 2. 컨테이너가 컨테이너를 보관하면 편리한 "자료구조"를 만들수 있습니다.
	std::vector< int > v1(10);


}
