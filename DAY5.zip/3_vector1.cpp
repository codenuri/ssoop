#include <iostream>
#include <vector>

// () 와 {} 차이

int main()
{
	std::vector<int> v1 = { 1,2,3,4,5 };
	
	


}
