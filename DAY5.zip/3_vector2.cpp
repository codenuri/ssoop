#include <iostream>
#include <vector>

int main()
{
	std::vector<int> v(8);

	v.resize(7);	// 어떻게 구현했을까 ?




}
